import React, { Component } from 'react';
import DropzoneComponent from 'react-dropzone-component';

class Upload extends Component {
    constructor() {
        super();
    }
    render() {

        return {

             <div>
	     	<h2> Upload your image </h2>
             </div>
        }
    }

}
export default Upload;
